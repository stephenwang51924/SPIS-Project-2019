import turtle
import numpy as np
import random
import c4Train as c4T
import pandas as pd
import pickle

def drawBoard(t):
    screen = turtle.Screen()
    screen.colormode(255)
    screen.bgcolor((102, 178, 255))
    t.hideturtle()
    t.speed(0)
    t.penup()
    t.setpos(-350, 0)
    t.left(90)
    t.pendown()
    t.forward(300)
    t.right(90)
    t.forward(710)
    t.right(90)
    t.forward(600)
    t.right(90)
    t.forward(710)
    t.right(90)
    t.forward(300)
    t.penup()
    for y in range(250, -251, -100):
        for x in range(-250, 351, 100):
            t.color("white")
            t.setpos(x, y)
            t.begin_fill()
            t.circle(45)
            t.end_fill()
    input()

def fillR(playerMove, t, col1, col2, col3, col4, col5, col6, col7):
    if playerMove == str(1):
        count = 6
        x = -250
        y = -250
        while count in col1:
            count -= 1
            y += 100
        t.color("red")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(2):
        count = 6
        x = -150
        y = -250
        while count in col2:
            count -= 1
            y += 100
        t.color("red")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(3):
        count = 6
        x = -50
        y = -250
        while count in col3:
            count -= 1
            y += 100
        t.color("red")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(4):
        count = 6
        x = 50
        y = -250
        while count in col4:
            count -= 1
            y += 100
        t.color("red")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()
    
    elif playerMove == str(5):
        count = 6
        x = 150
        y = -250
        while count in col5:
            count -= 1
            y += 100
        t.color("red")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(6):
        count = 6
        x = 250
        y = -250
        while count in col6:
            count -= 1
            y += 100
        t.color("red")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(7):
        count = 6
        x = 350
        y = -250
        while count in col7:
            count -= 1
            y += 100
        t.color("red")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

def fillY(playerMove, t, col1, col2, col3, col4, col5, col6, col7):
    if playerMove == str(1):
        count = 6
        x = -250
        y = -250
        while count in col1:
            count -= 1
            y += 100
        t.color("yellow")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(2):
        count = 6
        x = -150
        y = -250
        while count in col2:
            count -= 1
            y += 100
        t.color("yellow")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(3):
        count = 6
        x = -50
        y = -250
        while count in col3:
            count -= 1
            y += 100
        t.color("yellow")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(4):
        count = 6
        x = 50
        y = -250
        while count in col4:
            count -= 1
            y += 100
        t.color("yellow")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()
    
    elif playerMove == str(5):
        count = 6
        x = 150
        y = -250
        while count in col5:
            count -= 1
            y += 100
        t.color("yellow")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(6):
        count = 6
        x = 250
        y = -250
        while count in col6:
            count -= 1
            y += 100
        t.color("yellow")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

    elif playerMove == str(7):
        count = 6
        x = 350
        y = -250
        while count in col7:
            count -= 1
            y += 100
        t.color("yellow")
        t.setpos(x, y)
        t.begin_fill()
        t.circle(45)
        t.end_fill()

def chooseColor():
    color = input("Type Y if you want to be yellow and R if you want to be red.").upper()
    while not (color == "Y" or color == "R"):
        color = input("Type Y if you want to be yellow and R if you want to be red.").upper()
    return color

def addToList(move, col1, col2, col3, col4, col5, col6, col7, board, player):
    number = 1
    if player == "bot":
        number = 2
    if move == str(1):
        board[5 - len(col1), int(move) - 1] = number
        col1.append(6 - len(col1))
    elif move == str(2):
        board[5 - len(col2), int(move) - 1] = number
        col2.append(6 - len(col2))
    elif move == str(3):
        board[5 - len(col3), int(move) - 1] = number
        col3.append(6 - len(col3))
    elif move == str(4):
        board[5 - len(col4), int(move) - 1] = number
        col4.append(6 - len(col4))
    elif move == str(5):
        board[5 - len(col5), int(move) - 1] = number
        col5.append(6 - len(col5))
    elif move == str(6):
        board[5 - len(col6), int(move) - 1] = number
        col6.append(6 - len(col6))
    elif move == str(7):
        board[5 - len(col7), int(move) - 1] = number
        col7.append(6 - len(col7))

def winCon(board, player):
    number = 1
    if player == "bot":
        number = 2
    for col in range(7):
        for row in range(3):
            if board[row, col] == number and board[row + 1, col] == number and board[row + 2, col] == number and board[row + 3, col] == number:
                return True
    for row in range(6):
        for col in range(4):
            if board[row, col] == number and board[row, col + 1] == number and board[row, col + 2] == number and board[row, col + 3] == number:
                return True
    if board[2, 0] == number and board[3, 1] == number and board[4, 2] == number and board[5, 3] == number:
        return True
    for col in range(2):
        row = 1
        if board[row, col] == number and board[row + 1, col + 1] == number and board[row + 2, col + 2] == number and board[row + 3, col + 3] == number:
            return True
        else:
            row += 1
    for col in range(3):
        row = 0
        if board[row, col] == number and board[row + 1, col + 1] == number and board[row + 2, col + 2] == number and board[row + 3, col + 3] == number:
            return True
        else:
            row += 1
    for col in range(1, 4):
        row = 0
        if board[row, col] == number and board[row + 1, col + 1] == number and board[row + 2, col + 2] == number and board[row + 3, col + 3] == number:
            return True
        else:
            row += 1
    for col in range(2, 4):
        row = 0
        if board[row, col] == number and board[row + 1, col + 1] == number and board[row + 2, col + 2] == number and board[row + 3, col + 3] == number:
            return True
        else:
            row += 1
    if board[0, 3] == number and board[1, 4] == number and board[2, 5] == number and board[3, 6] == number:
        return True
    if (0 in board) == False:
        return True
    return False

def isColFull(colNum, col1, col2, col3, col4, col5, col6, col7):
    if colNum == 1:
        if len(col1) == 6:
            return True
    elif colNum == 2:
        if len(col2) == 6:
            return True
    elif colNum == 3:
        if len(col3) == 6:
            return True
    elif colNum == 4:
        if len(col4) == 6:
            return True
    elif colNum == 5:
        if len(col5) == 6:
            return True
    elif colNum == 6:
        if len(col6) == 6:
            return True
    elif colNum == 7:
        if len(col7) == 6:
            return True
    return False

"""def trainBot():
    dictGame = {}
    for number in range(5):
        data = c4T.getData()
        dictGame = c4T.buildDict(data, dictGame)
        print(number)
    return dictGame"""

"""def readData():
    df = pd.read_csv("testData.csv")
    df.to_dict()
    print(df)
    return df"""

def readData():
    with open('data.pickle', 'rb') as f:
        dictGame = pickle.load(f)
    return dictGame

def playBot(dictGame):
    t = turtle.Turtle()
    play = "YES"
    while play == "YES":
        t.reset()
        drawBoard(t)
        col1 = []
        col2 = []
        col3 = []
        col4 = []
        col5 = []
        col6 = []
        col7 = []
        board = np.zeros((6, 7))
        color = chooseColor()
        botColor = "Y"
        if color == "Y":
            botColor = "R"
        while True:
            playerMove = input("Enter the number of the column to make your move.")
            while not (playerMove == str(1) or playerMove == str(2) or playerMove == str(3) or playerMove == str(4) or playerMove == str(5) or playerMove == str(6) or playerMove == str(7)):
                    playerMove = input("Enter the number of the column to make your move.")
            while isColFull(int(playerMove), col1, col2, col3, col4, col5, col6, col7) == True:
                print("That column is full!")
                playerMove = input("Enter the number of the column to make your move.")
            if color == "Y":
                fillY(playerMove, t, col1, col2, col3, col4, col5, col6, col7)
                addToList(playerMove, col1, col2, col3, col4, col5, col6, col7, board, "player")
            else:
                fillR(playerMove, t, col1, col2, col3, col4, col5, col6, col7)
                addToList(playerMove, col1, col2, col3, col4, col5, col6, col7, board, "player")
            if winCon(board, "player") == True:
                break
            if str(board) in dictGame:
                nextMove = random.choice(dictGame[str(board)])
                for row in range(6):
                    for col in range(7):
                        if board[row, col] == 0 and nextMove[row, col] == 2:
                            botMove = str(col + 1)
                            if botColor == "Y":
                                fillY(botMove, t, col1, col2, col3, col4, col5, col6, col7)
                                addToList(botMove, col1, col2, col3, col4, col5, col6, col7, board, "bot")
                            else:
                                fillR(botMove, t, col1, col2, col3, col4, col5, col6, col7)
                                addToList(botMove, col1, col2, col3, col4, col5, col6, col7, board, "bot")
            else:
                while True:
                    col = random.randint(0, 6)
                    if isColFull(col + 1, col1, col2, col3, col4, col5, col6, col7) == False:
                        if botColor == "Y":
                            fillY(str(col + 1), t, col1, col2, col3, col4, col5, col6, col7)
                            addToList(str(col + 1), col1, col2, col3, col4, col5, col6, col7, board, "bot")
                            break
                        else:
                            fillR(str(col + 1), t, col1, col2, col3, col4, col5, col6, col7)
                            addToList(str(col + 1), col1, col2, col3, col4, col5, col6, col7, board, "bot")
                            break
                if winCon(board, "bot") == True:
                    break
        #if winCon(board) == True:
            #break
        play = input("Type YES if you want to play again and NO if you want to quit.").upper()
        while not (play == "YES" or play == "NO"):
            play = input("Type YES if you want to play again and NO if you want to quit.").upper()

if __name__ == "__main__":
    playBot(readData())
    #playBot(trainBot())
