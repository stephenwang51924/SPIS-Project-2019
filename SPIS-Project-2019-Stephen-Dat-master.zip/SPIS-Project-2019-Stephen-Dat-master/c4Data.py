import c4Train as c4T
import pandas as pd
import pickle

def trainBot():
    dictGame = {}
    for number in range(100000):
        data = c4T.getData()
        dictGame = c4T.buildDict(data, dictGame)
        print(number)
    return dictGame

#def saveData(dictGame):
    #df = pd.DataFrame(dictGame)
    #df.to_csv('testData.csv')

def saveData(dictGame):
    with open('data.pickle', 'wb') as f:
        pickle.dump(dictGame, f)

saveData(trainBot())
