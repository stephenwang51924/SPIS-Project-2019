import numpy as np
import random
import c4Bot as c4

def winMove(turn):
    for row in range(6):
        for col in range(7):
            if turn[row, col] == 0:
                turn[row, col] = 1
                if c4.winCon(turn, "player") == True:
                    return True
                else:
                    turn[row, col] = 0
    return False


def buildDict(game, dictGame):
    for board in range(len(game) - 1):
            if str(game[board]) not in dictGame:
                dictGame[str(game[board])] = []
                dictGame[str(game[board])].append(game[board + 1])
            else:
                dictGame[str(game[board])].append(game[board + 1])
    return dictGame

def getData():
    while True:
        col1 = []
        col2 = []
        col3 = []
        col4 = []
        col5 = []
        col6 = []
        col7 = []
        turn = np.zeros((6, 7))
        game = []
        while True:
            while True:
                if (0 in turn) == False:
                    break
                if winMove(turn) == True:
                    break
                col = random.randint(0, 6)
                if c4.isColFull(col + 1, col1, col2, col3, col4, col5, col6, col7) == False:
                    c4.addToList(str(col + 1), col1, col2, col3, col4, col5, col6, col7, turn, "player")
                    break
            game.append(np.copy(turn))
            if c4.winCon(turn, "player") == True:
                break
            while True:
                if (0 in turn) == False:
                    break
                col = random.randint(0, 6)
                if c4.isColFull(col + 1, col1, col2, col3, col4, col5, col6, col7) == False:
                    c4.addToList(str(col + 1), col1, col2, col3, col4, col5, col6, col7, turn, "bot")
                    if c4.winCon(turn, "bot"):
                        game.append(np.copy(turn))
                    break
            if c4.winCon(turn, "bot") == True:
                break
            if (0 in turn) == False:
                break
        if c4.winCon(turn, "bot") == True:
            return game
